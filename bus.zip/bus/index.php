<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/login.css">

	<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
	<script src="js/myjs.js"></script>	
		
	
	</head>
<body>
	<div id="id01" class="modal">  
	<div class="alert" id="myd">
		<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
			<center><strong id="errortext"></strong></center>
	</div>
	<?php
	error_reporting(0);
	include_once'mainfile/function.php';
	if($_SESSION['type']!=""){
		header('location:'.$_SESSION['type']);
	}
	
	if(isset($_POST['log'])){
		if($_SERVER["REQUEST_METHOD"]=="POST"){
			login($_POST);
		}
	}
?>
  <form id="myFormLogin" class="modal-content animate" method="post" action="">
    <div class="imgcontainer">
      <img src="img_avatar2.png" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label for="uname"><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="uname" id="uname" >

      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="psw" id="psw" >
      
	  <label for="type"><b>User Type</b></label>
      <select name="type" id="soflow" >
		<option value="">Select User Type</option>
		<option value="admin">Admin</option>
		<option value="student">Student</option>
	  </select>
        
      <button type="submit" name="log" value="Login">Login</button>

	</div>
	<div class="container" style="background-color:#f1f1f1; height:42px;">
      <span class="psw"><a href="signup.php">Student Register</a></span>
    </div>
	</form>
</div>
</body>
</html>
