<?php
	function connect(){
			$con = mysqli_connect("localhost","root","","projectbus") or die("Connection not Established");
			return $con;
	}

	
	
?>