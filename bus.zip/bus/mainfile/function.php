<?php
	include_once'connection.php';
	include_once'session.php';
	function login($a=array()){
		$con=connect();
		$q="select * from $a[type] where username='$a[uname]' and password='$a[psw]'";
		$r=mysqli_query($con,$q);
		if($row=mysqli_fetch_array($r)){
			$_SESSION['id']=$row["id"];
			$_SESSION['name']=$row["name"];
			$_SESSION['type']=$a["type"];
			header('location:'.$a['type']);
		}else{
	?>
			<div class="alert1" >
			<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
			<center><strong id="errortext">Username or Password Must Be Wrong...!!</strong></center>
		</div>
	<?php
		}
	}

	function checkBus($n){
		$con=connect();
		$q="select * from busroute where busno='$n'";
		$r=mysqli_query($con,$q);
		if($row=mysqli_fetch_array($r)){
			echo "0";
		}
	}
	function register($a=array()){
		$con=connect();
		$q="insert into student(name,username,password,phone,course) values('$a[name]','$a[uname]','$a[uname]','$a[phone]','$a[course]')";

		$r=mysqli_query($con,$q);
		if($r){
	?>
		<div class="alert alert-info" >
			<strong>Registration Done<br/> Your Student number is your username and password</strong>
		</div>
	<?php
		}else{
	?>
		<div class="alert alert-warning" >
			<strong>Failure in Process</strong>
		</div>
	<?php
		}
	}
	function changePassword($a=array()){
		$con=connect();
		$q="select * from $_SESSION[type] where id=$_SESSION[id] and password='$a[opass]'";
		$r=mysqli_query($con,$q);
		if($row=mysqli_fetch_array($r)){
			$x="update $_SESSION[type] set password='$a[npass]' where id=$_SESSION[id]";
			$y=mysqli_query($con,$x);
			if($y){
	?>
		<div class="alert alert-info" >
			<strong>Password Successfully Changed</strong>
		</div>
	<?php
			}else{
	?>
			<div class="alert alert-warning" >
				<strong>Failure in process</strong>
			</div>
	<?php
			}
		}else{
	?>
		<div class="alert alert-warning" >
			<strong>Old Password not matched</strong>
		</div>
	<?php
		}
	}

	function addBus($a=array()){
		$con=connect();
		$q="insert into busroute(busno,pickup,depart,day) values('$a[bus]','$a[pick]','$a[drop]','$a[day]')";
		$r=mysqli_query($con,$q);
		if($r){
	?>
		<div class="alert alert-info" >
			<strong>New Bus Successfully Added</strong>
		</div>
	<?php
		}else{
	?>
		<div class="alert alert-warning" >
			<strong>Failure in Process</strong>
		</div>
	<?php
		}
	}

	function addBusTime($a=array()){
		$con=connect();
		$q="insert into timebus(busid,timebus) values('$a[bidn]','$a[bustime]')";
		$r=mysqli_query($con,$q);
		if($r){
			$st='<div class="alert alert-info" ><strong>New Bus Time Successfully Added</strong></div>';
			$_SESSION['status']=$st;
			header('location:list.php');
		}else{
			$st='<div class="alert alert-warning" ><strong>Failure in Process</strong></div>';
			$_SESSION['status']=$st;
			header('location:list.php');
		}
	}

	function getallPickupLocation(){
		$con=connect();
		$q="select distinct pickup from busroute";
		$r=mysqli_query($con,$q);
		while($row=mysqli_fetch_array($r)){
			echo "<option>".$row['pickup']."</option>";
		}

	}

	function allTimeBusSpecific($a=array()){
		$count=1;
		$con=connect();
		$q="select * from timebus where busid='$a[bid]' order by id ASC";
		$r=mysqli_query($con,$q);
		while($row=mysqli_fetch_assoc($r)){
	?>
		<tr>
			<td><?php echo $count;?></td>
			<td><?php echo $a['all'];?></td>
			<td><?php echo date("g:i a", strtotime($row['timebus']));?></td>
			<?php
				if($_SESSION['type']=="admin"){
			?>
			<td>
				<form action="editbustime.php" method="post">
					<input type="hidden" name="bustime" value="<?php echo $row['timebus'];?>">
					<input type="hidden" name="busno" value="<?php echo $a['all'];?>">
					<button type="submit" class="btn btn-link" style="padding:0px;font-size:18px;color:#F0AD4E;" name="editbustime" value="<?php echo $row['id'];?>"><i class="fa fa-pencil"></i></button>
				</form>
			</td>
			<td>
				<button type="button" class="btn btn-link delbtn" style="padding:0px;font-size:18px;color:#D9534F;" name="<?php echo $row['id'];?>"  id="del"><i class="fa fa-trash"></i></button>
			</td>
			<td>
				<button type="button" class="btn btn-link sndsms" style="padding:0px;font-size:18px;color:#D9534F;" value="<?php echo $row['id'];?>" >
				<i class="fa fa-envelope"></i>
			</button>
			</td>

				<?php } ?>
        </tr>
	<?php
		$count++;
		}
	}
	function deletespecifictime($id){
		$con=connect();
		$q="delete from timebus where id=$id";
		$r=mysqli_query($con,$q);
		if($r){
			$st='<div class="alert alert-info" ><strong>Data Successfully Deleted</strong></div>';
			$_SESSION['status']=$st;
			header('location:list.php');
		}else{
			$st='<div class="alert alert-warning" ><strong>Failure in Process</strong></div>';
			$_SESSION['status']=$st;
			header('location:list.php');
		}
	}


	function deletespecificbus($id){
		$con=connect();
		$q="DELETE a.*, b.* from busroute a left join timebus b On a.id=b.busid where a.id=$id";
		$r=mysqli_query($con,$q);
		if($r){
			$st='<div class="alert alert-info" ><strong>Data Successfully Deleted</strong></div>';
			$_SESSION['status']=$st;
			header('location:list.php');
		}else{
			$st='<div class="alert alert-warning" ><strong>Failure in Process</strong></div>';
			$_SESSION['status']=$st;
			header('location:list.php');
		}
	}

	function editBusTime($a=array()){
		$con=connect();
		$q="update timebus set timebus='$a[bustime]' where id='$a[bidn]'";

		$r=mysqli_query($con,$q);
		if($r){
			$st='<div class="alert alert-info" ><strong>Data Successfully Updated</strong></div>';
			$_SESSION['status']=$st;
			header('location:list.php');
		}else{
			$st='<div class="alert alert-warning" ><strong>Failure in Process</strong></div>';
			$_SESSION['status']=$st;
			header('location:list.php');
		}
	}

	function buyTicket($name){

		$con=connect();

		$date = date("d/m/Y");
		$c=0;
		$qf="select * from timebus where id='$name'";
		$rf=mysqli_query($con,$qf);
		if($rowf=mysqli_fetch_array($rf)){
			$c=$rowf['ticket'];
		}
		$q="select * from datecheck where date='$date' and busid='$name'";
		$check=0;
		$r=mysqli_query($con,$q);
		if($row=mysqli_fetch_array($r)){


			$cticket=$row['ticket'];
			if($c>$cticket){
				$cticket++;
				$qa="update datecheck set ticket='$cticket'  where date='$date' and busid='$name'";
				$ra=mysqli_query($con,$qa);
				if($ra){
					$total=$c-$cticket;
					echo "1/$total";
					$check=1;
				}else{
					echo "2";
				}
			}else{
				echo "3";
			}
		}else{
			$qu="insert into datecheck (date,busid,ticket) values('$date','$name','1')";
			$ru=mysqli_query($con,$qu);
			if($ru){
				$total=$c-1;
				echo "1/$total";
				$check=1;
			}else{
				echo "3";
			}
		}
		if($check==1){
			$queryi="insert into bususerticket(studentid,busid,date) values('$_SESSION[id]','$name','$date')";
			$rquery=mysqli_query($con,$queryi);
		}
	}

	function allBusRoute(){
		$count=1;
		$con=connect();

		$q="select * from busroute";
		$r=mysqli_query($con,$q);
		while($row=mysqli_fetch_assoc($r)){
	?>
		<tr>
			<td><?php echo $count;?></td>
			<td><?php echo $row['busno'];?></td>
			<td><?php echo $row['pickup'];?></td>
			<td><?php echo $row['depart'];?></td>
			<?php
				$d="";
				if($row['day']=="1"){
					$d="Mon - Sat";
				}else if($row['day']=="2"){
					$d="Only Saturday";
				}else if($row['day']=="3"){
					$d="Mon - Fri";
				}
			?>
			<td><?php echo $d;?></td>
			<td>
			<form method="post" action="allbustime.php">
				<input type="hidden" name="bid" value='<?php echo $row['id'];?>'>
				<button type="submit" class="btn btn-link" style="padding:0px;font-size:18px;color:#5CB85C;" name="all" value="<?php echo $row['busno'];?>"><i class="fa fa-clock-o"></i></button>
			</form>
			</td>
			<?php
				if($_SESSION['type']=="admin"){
			?>
			<td>

				<form action="addnewtimeforbus.php" method="post">
					<input type="hidden" name="bid" value='<?php echo $row['id'];?>'>
					<button type="submit" class="btn btn-link" style="padding:0px;font-size:18px;color:#F0AD4E;" name="addnew" value="<?php echo $row['busno'];?>"><i class="fa fa-pencil"></i></button>
				</form>
			</td>
			<td>
				<button type="submit" class="btn btn-link deletebus" name="<?php echo $row['id'];?>" style="color:#D9534F;padding:0px;font-size:18px;"><i class="fa fa-trash"></i></button>
			</td>
			<?php } ?>

        </tr>

	<?php
		$count ++;
		}
	}


	function allBusPassenger($a=array()){
		$con=connect();
		$date = date("d/m/Y");
		$q="select * from bususerticket where date='$date' and busid='$a[getlist]'";
		$c=1;
		$r=mysqli_query($con,$q);
		while($row=mysqli_fetch_array($r)){
			$er="select * from student where id=$row[studentid]";
			$rr=mysqli_query($con,$er);
			if($rowe=mysqli_fetch_array($rr)){
	?>
		<tr>
			<td><?php echo $c;?></td>
			<td><?php echo $rowe['name'];?></td>
			<td><?php echo $rowe['username'];?></td>
			<td><?php echo $rowe['course'];?></td>
		</tr>
	<?php
			}
		$c++;
		}
	}

	function allBusRouteLoc($loc){
		$rdate=date("l");
		$day="";

		if($rdate=="Sunday"){
			return false;
		}
		else if($rdate!="Saturday"){
			$day="and day='1' or pickup='$loc' and day='3'";

		}else if($rdate=="Saturday"){
			$day="and day='1' ";
		}
		date_default_timezone_set("America/New_York");
		$now = new DateTime();
		$xyz=$now->format('H:i:s');
		$count=1;
		$con=connect();
		$q="select * from busroute where pickup='$loc' $day";

		$r=mysqli_query($con,$q);
		while($row=mysqli_fetch_array($r)){
			$t="select * from timebus where busid='$row[id]' and timebus>='$xyz' ORDER BY timebus ASC";
			$rw=mysqli_query($con,$t);
			while($roww=mysqli_fetch_array($rw)){
				$date = date("d/m/Y");
				$avail=0;
					$tot=$roww['ticket'];
				$qr="select * from datecheck where busid='$roww[id]' and date='$date'";
				$rr=mysqli_query($con,$qr);
				if($rowr=mysqli_fetch_array($rr)){
					$avail=$rowr['ticket'];
				}
				$msg="";
				$final=$tot-$avail;
				if($final==0){
					$msg="disabled='true'";
				}
	?>
				<tr>
					<td><?php echo $count; ?></td>
					<td><?php echo $row['busno']; ?></td>
					<td><?php echo $row['pickup']; ?></td>
					<td><?php echo $row['depart']; ?></td>
					<td><?php echo date("g:i a", strtotime($roww['timebus'])); ?></td>
					<td id="available_<?php echo $roww['id'];?>"><?php echo $final; ?></td>
					<?php

						if($_SESSION['type']=="student"){
					?>

					<td><button <?php echo $msg;?> value="<?php echo $roww['id'];?>" id='btntic_<?php echo $roww['id'];?>' type="button" class="btn btn-link btntick" style="color:#F0AD4E;"><i class="fa fa-money "></i></button></td>
					<?php
						}else if($_SESSION['type']=="admin"){
					?>
						<td>
							<form action="passenger.php" method="post">
								<button value="<?php echo $roww['id'];?>" type="submit" name="getlist" class="btn btn-link" style="color:#F0AD4E;"><i class="fa fa-search "></i></button>
							</form>
						</td>
					<?php
						}
					?>
				</tr>
	<?php
			$count++;
			}
		}
	}

	?>
