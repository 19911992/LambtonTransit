$(document).ready(function(){
	
	$('#searchbyloc').submit(function(){
		if($('#loc').val()==""){
			$('#myd').show();
			$('#errortext').text("Please Select Location");
			return false;
		}
	});
	
	$('#myFormLogin').submit(function(){
		if($('#uname').val()=="" || $('#psw').val()=="" || $('#soflow').val()==""){
			$('#myd').slideDown();
			$('#errortext').text("All Fields are required");
			return false;
		}
	});	
	$('#addbus').submit(function(){
		if($('#bus').val()=="" || $('#pick').val()=="" || $('#drop').val()=="" || $('#day').val()==""){
			$('#myd').show();
			$('#errortext').text("All Fields are required");
			return false;
		}
	
	});
	$('#passwordForm').submit(function(){
		if($('#opass').val()=="" || $('#npass').val()=="" || $('#cpass').val()==""){
			$('#myd').show();
			$('#errortext').text("All Fields are required");
			return false;
		}
		else if($('#npass').val()!=$('#cpass').val()){
			$('#myd').show();
			$('#errortext').text("Password not matched");
			return false;
		}
	});
	
	$('#bus').blur(function(){
		var name=$('#bus').val();
		var xmlhttp=new XMLHttpRequest();
		xmlhttp.onreadystatechange=function(){
			if(xmlhttp.readyState==4 && xmlhttp.status==200){
					if(xmlhttp.responseText.trim()=="0"){
						$('#myd').show();
						$('#errortext').text("Bus number already exist");
						$('#btnAdd').attr('disabled','true');
					}else{
						$('#myd').hide();
						$('#errortext').text("");
						$('#btnAdd').removeAttr('disabled');
					}
			}
		}
		xmlhttp.open("GET","checkbus.php?name="+name,true);
		xmlhttp.send();
	});
	
	
	$('.sndsms').click(function(){
		var name=$(this).val();

		var xmlhttp=new XMLHttpRequest();
		xmlhttp.onreadystatechange=function(){
			if(xmlhttp.readyState==4 && xmlhttp.status==200){
					alert(xmlhttp.responseText.trim())
			}
		}
		xmlhttp.open("GET","sendSms.php?name="+name,true);
		xmlhttp.send();
	});

	
	$('#formbus').submit(function(){
		if($('#bustime').val()==""){
			$('#myd').show();
			$('#errortext').text("Please Enter Bus Time");
			return false;
		}
	
	});
	
	
	$('.btntick').click(function(){
		var r = confirm("Are you Sure you want to buy ticket "); 
		if (r==true) {
			var name=$(this).attr('value');
			
			var xmlhttp=new XMLHttpRequest();
			xmlhttp.onreadystatechange=function(){
				if(xmlhttp.readyState==4 && xmlhttp.status==200){
						if(xmlhttp.responseText.trim()=="2"){
							alert(xmlhttp.responseText.trim());
							$('#myd').show();
							$('#errortext').text("Failure in Process");
						}else if(xmlhttp.responseText.trim()=="3"){
							$('#btntic_'+name).attr('disabled','true');
							$('#available_'+name).text("Sold Out");
						}else{
							var a=xmlhttp.responseText.trim();
							var b=a.split("/");
							if(b[1]==0){
								$('#available_'+name).text("Sold Out");
							}else{
								$('#available_'+name).text(b[1]);
							}
								$('#btntic_'+name).attr('disabled','true');
								$('#myd').show();
								$('#errortext').text("Transaction Completed");
								
						}
				}
			}
			xmlhttp.open("GET","buy.php?name="+name,true);
			xmlhttp.send();
        }
	});

	
	$('.delbtn').click(function(){
        var r = confirm("Are you Sure you want to delete this entry ");
        if (r==true) {
            window.location.replace("deletebustime.php?value="+$(this).attr('name'));
        }
    });
	
	
	$('.deletebus').click(function(){
        var r = confirm("Are you Sure you want to delete this entry ");
        if (r==true) {
            window.location.replace("deletebus.php?value="+$(this).attr('name'));
        }
    });
	
});